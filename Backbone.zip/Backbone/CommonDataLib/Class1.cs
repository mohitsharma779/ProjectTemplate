﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonDataLib
{
    public class Class1
    {
    }
}
