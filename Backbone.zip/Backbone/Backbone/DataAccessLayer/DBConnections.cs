﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Backbone.DataAccessLayer
{
    public class DBConnections
    {
    }
}